# Live Chat — setup

## 1. Copy files into your project
Copy everything under `src/` in this bundle into your real project's `src/`, keeping the same paths:

- `src/app/api/live-chat/route.ts`
- `src/components/livechat/LiveChatWindow.tsx`
- `src/app/admin/live-chat/page.tsx`
- `src/app/watch/[profileslug]/livechat/page.tsx`

## 2. Add the DB model
Open `prisma/schema.prisma` and paste in the contents of `prisma-schema-addition.prisma` (anywhere at the top level).

Then run, on your machine or the VM:

```bash
npx prisma migrate dev --name add_live_chat
npx prisma generate
```

(SQLite — no extra config needed.)

## 3. Add a sidebar link in the admin panel
In `src/components/admin/AdminSidebar.tsx`, add one line to `sidebarLinks` (I used the `MessageSquare` icon that's already imported):

```ts
{ label: "Live Chat", href: "/admin/live-chat", icon: MessageSquare },
```

## 4. Add the "Live Chat" tab for your gf's viewer nav
Your project already has a Nav Tabs admin page (`/admin/nav-tabs`) that manages which tabs show up on the viewer top nav. Two ways to add it:

**Easiest — through the UI:**
1. Go to `/admin/nav-tabs`
2. Add a tab with slug `livechat` and label `Live Chat`

If the "Add tab" dropdown only offers a fixed list, open `src/app/admin/nav-tabs/page.tsx` and add this entry to `AVAILABLE_TABS`:

```ts
{ slug: "livechat", label: "Live Chat", kind: "LIVE_CHAT" },
```

(The `kind` value isn't actually used for routing in this app — each slug maps to its own page folder under `src/app/watch/[profileslug]/`, which is exactly what `livechat/page.tsx` provides — so any string works there.)

## 5. Rebuild & deploy
```bash
npm run build
pm2 restart all   # or however you're running the Next.js process on your VM
```

## How it works
- One shared `LiveChatMessage` table. `sender` is `"admin"` or `"viewer"`, taken straight from your existing session/auth (no new login system).
- The chat UI polls `/api/live-chat` every 2 seconds and instantly re-fetches on tab focus, so it feels live without needing a WebSocket server (simplest thing that reliably works behind a plain `next start` + nginx on a VM, no socket infra to babysit).
- Sending is optimistic — your message appears instantly, then gets reconciled with the real saved row.
- Opening the chat marks the other person's unread messages as read (`readAt`), which we'll use for notification logic next.

## Next steps (once you confirm this works)
1. **Notifications** — Telegram bot (instant, free, dead simple: just a bot token + your chat ID, one HTTP POST per new message) + email as backup. I'll hook this into the POST route so it fires whenever the *other* role sends a message.
2. **Voice/video calling** — WebRTC with a free STUN/TURN service (e.g. a free Metered.ca or Twilio TURN allowance) for the actual peer connection, plus a lightweight signaling channel. Since you're on a VM (not serverless), we can either reuse polling for signaling or add a small `ws` signaling server — the VM makes this easy since you have a persistent process.

Let me know once the chat is deployed and working, and we'll move on to notifications.
